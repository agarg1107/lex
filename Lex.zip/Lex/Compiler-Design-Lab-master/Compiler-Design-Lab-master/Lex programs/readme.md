# Lex Programs

## Running the programs

lex filename.l
gcc lex.yy.c
./a.out

#### Contributing
Contributions are always welcome. In the case of a bug report, bugfix or a suggestions, please feel very free to open an issue. Pull requests are always welcome, and I'll do my best to do reviews as fast as I can.

#### Acknowledgments

* Hat tip to anyone whose code was used
